const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use('/images', express.static('images'));

// Datos de ejemplo (productos para mascotas)
const productos = [
    { id: 1, 
        nombre: 'Arnés Premium', 
        precio: 23.00, 
        imagen: 'https://www.animalia.com.ar/wp-content/uploads/2019/01/1.png' },
   
    { id: 2, 
        nombre: 'Juguete para perro', 
        precio: 12.50, 
        imagen: 'https://m.media-amazon.com/images/I/71uYIMAYRsL._AC_UF1000,1000_QL80_.jpg' },

    { id: 3, 
        nombre: 'Comedero para gato', 
        precio: 8.50, 
        imagen: 'https://www.lavanguardia.com/files/og_thumbnail/files/fp/uploads/2024/03/08/65ead53f899b4.r_d.369-210-16238.png' },

    { id: 4, 
        nombre: 'Pelota para perro', 
        precio: 5.50, 
        imagen: 'https://cdnx.jumpseller.com/cody-store/image/29414580/resize/1200/1200?1668377107' },

    { id: 5, 
        nombre: 'Cama para gato', 
        precio: 35.00, 
        imagen: 'https://cdn1.coppel.com/images/catalog/mkp/2014/3000/20141022-2.jpg?iresize=width:400,height:320' },

    { id: 6, 
        nombre: 'Correa Reflectante', 
        precio: 15.75, 
        imagen: 'https://upload.cdn.baselinker.com/products/3012437/88a330e94c78dbc7be1b53fef6f25944.jpg' },

    { id: 7, 
        nombre: 'Rascador para gato', 
        precio: 21.00, 
        imagen: 'https://storage.googleapis.com/catalog-pictures-carrefour-es/catalog/pictures/hd_510x_/4099917174498_1.jpg' },

    { id: 8,
    nombre: 'Alimento Premium para Perro', 
    precio: 42.00, 
    imagen: 'https://tiendademascotasar.vtexassets.com/arquivos/ids/157037/ALPE946-1.jpg?v=637735501512570000' }
];

// Ruta para obtener todos los productos
app.get('/api/productos', (req, res) => {
    res.json(productos);
});

// Ruta para la raíz del servidor
app.get('/', (req, res) => {
    res.json(productos);
});

// Iniciar el servidor
app.listen(port, () => {
    console.log(`API corriendo en http://localhost:${port}`);
});